#!/usr/bin/env bash

hg archive ~/Desktop/vitality.zip -I 'doc' -I 'plugin' -I README.markdown -I LICENSE.markdown
