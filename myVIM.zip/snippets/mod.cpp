template<int MOD>
class Num {
private:
    int expow(long base, int e) const {
	long long ans = 1;
        for (; e > 0; e/= 2) {
	    if (e % 2)
		ans = ans * base % MOD;
	    base = base * base % MOD; }
        return ans; }
		     
public:
    int val;

    Num(long long _val) {
        val = _val % MOD;
        val = val < 0 ? val + MOD : val; }

    Num() : val(0) { }
				 
    inline Num operator + (const Num &arg) const {
        Num res;
        res.val = val + arg.val;
        res.val = res.val >= MOD ? res.val - MOD : res.val;
        return res; }
				     
    inline Num operator - (const Num &arg) const {
	Num res;
	res.val = val - arg.val;
	res.val = res.val < 0 ? res.val + MOD : res.val;
	return res; }
					 
    inline Num operator - () const {
        Num res;
        res.val = MOD - res.val;
        res.val = res.val == MOD ? 0 : res.val;
        return res; }
					     
    inline Num operator ^ (const int &arg) const {
	return Num(expow(val, arg)); }
						 
    inline Num operator * (const Num &arg) const {
        return Num(1LL * val * arg.val); }
						     
    inline Num operator / (const Num &arg) const {
    	return Num(1LL * val * expow(arg.val, MOD - 2)); }
							 
    inline void operator += (const Num &arg) {
        (*this) = (*this) + arg; }
							     
    inline void operator -= (const Num &arg) {
	(*this) = (*this) - arg; }
								 
    inline void operator *= (const Num &arg) {
        (*this) = (*this) * arg; }
								     
    inline void operator /= (const Num &arg) {
	(*this) = (*this) / arg; }

    inline void operator ^= (const long long &arg) {
	val = expow(val, arg); } };
 
template<int MOD>
ostream &operator << (ostream &fo, const Num<MOD> &c) {
    fo << c.val;
    return fo; }
		 
template<int MOD>
    istream &operator >> (istream &fi, Num<MOD> &c) {
    fi >> c.val;
    c = Num<MOD>(c.val);
    return fi; }

