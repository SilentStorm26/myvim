#include <bits/stdc++.h>

#define x first
#define y second
using namespace std;

using i64 = long long;
using f64 = double;
using f80 = long double;
using pii = pair<int, int>;
using ptx = pair<f64, f64>;


int main() {
#ifdef HOME
    freopen("dat.in", "r", stdin);
    freopen("dat.out", "w", stdout);
#endif
    ios::sync_with_stdio(false);
    cin.tie(0), cout.tie(0);

    return 0;
}

