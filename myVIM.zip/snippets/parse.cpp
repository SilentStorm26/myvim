class ParseIn {
private:
    FILE *fi;

    static inline char nextch() {
	const int BMAX = 1 << 17;
        static char buff[BMAX];
	static int bp = BMAX;

	if (bp == BMAX) {
	    fread(buff, 1, BMAX, stdin);
	    bp = 0;
	}
	return buff[ bp++ ];
    }

public:
    ParseIn() {	fi = stdin; }
    ParseIn(string file) { freopen(file.c_str(), "r", fi); }

    // BEWARE OF NEGATIVE NUMBERS !!!!!!!!!!!!!!!

/*
    ParseIn &operator >> (int &x) { 
	char ch;
	do {
	    ch = nextch();
	}
	while (!('0' <= ch && ch <= '9'));
	x = 0;
	while ('0' <= ch && ch <= '9') {
	    x = x * 10 + (ch - '0');
	    ch = nextch();
	}

	return *this;
    }
/*/
    ParseIn &operator >> (int &x) {
	char ch;
	int sgn = 1;

	do {
	    ch = nextch();
	}
	while (!('0' <= ch || ch <= '9') && ch != '-');
	x = 0;
	if (ch == '-') {
	    sgn = -1;
	    ch = nextch();
	}
	while ('0' <= ch && ch <= '9') {
    	    x = x * 10 + (ch - '0');
	    ch = nextch();
	}
	x*= sgn;

	return *this;
    }


    ParseIn &operator >> (char &x) {
	do {
	    x = nextch();
	}
	while(isspace(x));
	return *this;
    }
//*/
};

